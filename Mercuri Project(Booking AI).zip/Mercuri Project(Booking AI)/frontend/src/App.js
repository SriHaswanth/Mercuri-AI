import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

const API_BASE = 'http://localhost:5000/api';

function App() {
  const [slots, setSlots] = useState([]);
  const [userName, setUserName] = useState('');
  const [prompt, setPrompt] = useState('');
  const [agentResponse, setAgentResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchSlots = async () => {
    try {
      const res = await axios.get(`${API_BASE}/slots/available`);
      setSlots(res.data);
    } catch (err) {
      console.error('Error fetching slots:', err);
    }
  };

  useEffect(() => {
    fetchSlots();
  }, []);

  const handleManualBook = async (slotId) => {
    if (!userName.trim()) {
      alert('Please enter your name first.');
      return;
    }
    try {
      await axios.post(`${API_BASE}/bookings/manual`, { slotId, userName });
      fetchSlots();
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to book slot.');
    }
  };

  const handleAgentSubmit = async (e, customPrompt) => {
    if (e) e.preventDefault();
    const textToSend = customPrompt || prompt;
    if (!textToSend.trim()) return;

    setLoading(true);
    setAgentResponse('');
    try {
      const res = await axios.post(`${API_BASE}/agent/book`, {
        prompt: textToSend,
        userName: userName || 'Guest'
      });
      setAgentResponse(res.data.message);
      fetchSlots();
      setPrompt('');
    } catch (err) {
      setAgentResponse(err.response?.data?.error || 'Agent encountered an error.');
    } finally {
      setLoading(false);
    }
  };

  const quickSuggestions = [
    'Book the earliest available slot',
    'Book tomorrow afternoon',
    'Book something Friday morning'
  ];

  return (
    <div className="container">
      <header>
        <h1>Appointment Booking</h1>
        <p className="subtitle">Book open slots manually or request one naturally via the AI agent.</p>
      </header>

      <div className="name-input-container">
        <label htmlFor="user-name">Booking Name:</label>
        <input
          id="user-name"
          type="text"
          placeholder="Enter your name (e.g. Alex)"
          value={userName}
          onChange={(e) => setUserName(e.target.value)}
        />
      </div>

      <div className="grid">
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">Available Slots</h2>
            <span className="badge">{slots.length} Open</span>
          </div>

          <div className="slots-list">
            {slots.length === 0 ? (
              <div className="empty-state">No open slots available.</div>
            ) : (
              slots.map((s) => {
                const start = new Date(s.startTime);
                return (
                  <div key={s._id} className="slot-item">
                    <div className="slot-info">
                      <span className="slot-date">
                        {start.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                      </span>
                      <span className="slot-time">
                        {start.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}
                      </span>
                    </div>
                    <button className="btn btn-outline" onClick={() => handleManualBook(s._id)}>
                      Book
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h2 className="card-title">AI Booking Agent</h2>
            <span className="badge">Natural Language</span>
          </div>

          <form className="agent-form" onSubmit={(e) => handleAgentSubmit(e)}>
            <div className="agent-input-container">
              <input
                type="text"
                placeholder="e.g. Book me something tomorrow afternoon"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Thinking...' : 'Send'}
              </button>
            </div>

            <div className="suggestions">
              {quickSuggestions.map((item, idx) => (
                <span
                  key={idx}
                  className="suggestion-chip"
                  onClick={() => handleAgentSubmit(null, item)}
                >
                  {item}
                </span>
              ))}
            </div>
          </form>

          {agentResponse && (
            <div className="chat-box">
              <div className="chat-avatar">AI</div>
              <div className="chat-content">{agentResponse}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;